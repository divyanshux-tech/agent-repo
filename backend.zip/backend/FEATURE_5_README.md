# Feature 5 — Travel Agent (Flights + Trains)

This module implements the **Travel Agent**, a specialist agent responsible for fetching flight and train options for a selected destination. 

## Architecture
- **Parallel Execution:** It leverages Python's `asyncio.gather` to concurrently query flights (Aviationstack) and trains (Indian Rail via RapidAPI), optimizing response time.
- **Fail-Safe Fallbacks:** If the aviation API rate-limits or fails, the agent continues and returns train options gracefully (and vice versa). Exceptions are returned as structured `warnings`.
- **Curation & Deduping:** Candidates are sorted by travel duration and price. We return a maximum of 5 flights and 5 trains. Exact duplicates (if logically possible) are merged based on the cheaper option.
- **Unified Schemas:** Both flight and train candidates map to a single Pydantic schema (`TravelCandidate`) enabling downstream modules (like the Optimizer) to ingest them agnostically.
- **Supabase Persistence:** Results are saved to the `trip_candidates` table with `superseded_at` lifecycle tracking, allowing replanning without deleting historical context.

## External API Requirements
You must obtain API keys for both providers and set them in your `.env`:

1. **Aviationstack (Flights)**: 
   - Get a free key (500 calls/mo) at https://aviationstack.com
   - Set `AVIATIONSTACK_ACCESS_KEY=your_key_here`
   - Set `AVIATIONSTACK_BASE_URL=https://api.aviationstack.com/v1`

2. **Indian Rail (RapidAPI)**: 
   - Subscribe to an Indian Rail API on RapidAPI (e.g. `indianrailapi.com`).
   - Set `RAPIDAPI_KEY=your_rapidapi_key`
   - Set `RAPIDAPI_INDIAN_RAIL_HOST=indianrailapi.com`
   - Set `RAPIDAPI_INDIAN_RAIL_BASE_URL=https://indianrailapi.com/api/v1`

## Caching strategy
- **Flights**: Cached in memory by `(origin, destination, date)` for 1 hour.
- **Trains**: Cached in memory for 30 minutes.

## Running Tests
Tests are located in `backend/tests/test_travel_agent.py` and heavily utilize `unittest.mock` to ensure no live API keys are required during testing.
```bash
python -m pytest tests/test_travel_agent.py
```
