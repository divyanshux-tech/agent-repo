# Destination Recommendation Agent

This document explains the mechanics of the deterministic Destination Recommendation Agent (Feature 4).

## Architecture
The agent is entirely deterministic, bypassing LLMs to guarantee sub-200ms latency. The orchestration layer routes `RECOMMEND_DESTINATIONS` intents to the `/api/destination-agent/recommend` endpoint.

## The Hybrid Scorer
We score all destinations in the catalog (`backend/data/destinations.json`) on four axes, returning a score from 0.0 to 1.0.

1. **Interest Match (α=0.4)**: Jaccard similarity between user's extracted interests and the destination's tags + `best_for_interests`. A +0.1 bonus is given if a "best_for" tag matches.
2. **Season Fit (β=0.3)**: 1.0 if traveling during peak season, 0.9 for off-peak season months. Degrades linearly down to 0.0 for out-of-season months.
3. **Budget Fit (γ=0.2)**: 1.0 if the user has 2x the standard per-person-per-day rate of the destination's tier. 0.8 if covering the base cost, dropping sharply if underfunded.
4. **Novelty Bonus (δ=0.1)**: Rewards `low` footfall destinations if the user prefers offbeat locations or avoids crowds.

**Tuning Weights:**
You can tune the formula instantly without restarting the server by setting the environment variable:
`DESTINATION_SER_WEIGHTS='{"alpha": 0.5, "beta": 0.2, "gamma": 0.2, "delta": 0.1}'`

## Long-Tail Novelty Floor
To combat generic "Top 10" recommendations, the Selector enforces a mathematical floor: at least 20% of any final shortlist (rounded up) *must* be `footfall=low`. If the highest-scoring destinations are all mainstream, the weakest mainstream ones are swapped out for the strongest hidden gems. 

## Personalization
If an authenticated user makes a request, the router attempts to fetch `user_trip_memory` (previous trips). If previous interests overlap with a destination's tags, we apply a strict +0.05 bonus to the `interest_match`. Additionally, if a destination name is explicitly in the user's raw query (e.g., "Goa jaana hai"), it receives a massive +2.0 boost to ensure it surfaces as rank #1.

## Performance Characteristics
- **Latency**: < 200ms round-trip.
- **Memory Footprint**: < 10MB (The JSON catalog is loaded precisely once at module initialization).

## Known Limitations
- The catalog is currently statically seeded in JSON. Adding a new destination requires manual JSON appending, though no code changes are necessary.
- Does not currently factor in real-time weather APIs.
